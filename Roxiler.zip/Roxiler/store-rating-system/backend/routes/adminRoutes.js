const express = require("express");

const router = express.Router();

const {
  createAdmin,
  createUser,
  createStore,
} = require("../controllers/adminController");


router.post(
  "/create-admin",
  createAdmin
);

router.post(
  "/create-user",
  createUser
);

router.post(
  "/create-store",
  createStore
);

module.exports = router;