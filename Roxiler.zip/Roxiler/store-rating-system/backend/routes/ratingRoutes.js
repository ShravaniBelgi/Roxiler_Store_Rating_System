const express = require("express");
const router = express.Router();

const {
  addRating,
  getStoreReviews,
  getAllRatings
} = require("../controllers/ratingController");

router.post("/", addRating);

router.get(
  "/store/:storeId",
  getStoreReviews
);
router.get("/", getAllRatings);
module.exports = router;