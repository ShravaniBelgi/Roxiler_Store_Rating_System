const express = require("express");
const router = express.Router();

const {
  getUsers,
  getUserById,
  deleteUser,
    getProfile,
addUser,
getAllUsers
} = require("../controllers/userController");

router.get("/", getUsers);

router.get("/:id", getUserById);

router.delete("/:id", deleteUser);
router.get("/profile/:id", getProfile);
router.post("/add", addUser);
router.get("/", getAllUsers);
module.exports = router;
