const express = require("express");

const router = express.Router();

const {
  register,
  login,
} = require("../controllers/authController");

router.post("/register", register);

router.post("/login", login);



const {
  
  resetPassword,
} = require("../controllers/authController");

router.post("/register", register);
router.post("/login", login);

router.put("/reset-password", resetPassword);

module.exports = router;

module.exports = router;