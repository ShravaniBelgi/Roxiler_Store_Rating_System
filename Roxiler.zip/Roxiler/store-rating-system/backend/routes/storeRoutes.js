const express = require("express");
const router = express.Router();

const {
  getStores,
  getStoreById,
  addStore,
  deleteStore,
  getAllStores,
  getMyStore,
    getStoresForUser,

} = require("../controllers/storeController");

router.get("/", getStores);

// GET all stores with current user's review details
router.get("/", getStoresForUser);
router.get("/:id", getStoreById);
router.get("/my-store", getMyStore);

// router.post("/", addStore);
router.post("/add", addStore);
router.delete("/:id", deleteStore);
router.get("/", getAllStores);
module.exports = router;