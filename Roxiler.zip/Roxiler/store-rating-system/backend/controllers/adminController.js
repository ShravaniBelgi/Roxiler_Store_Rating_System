const db = require("../config/db");
const bcrypt = require("bcryptjs");


// ======================
// DASHBOARD STATS
// ======================

exports.getDashboardStats = (req, res) => {
  const sql = `
    SELECT
      (SELECT COUNT(*) FROM users) AS totalUsers,
      (SELECT COUNT(*) FROM stores) AS totalStores,
      (SELECT COUNT(*) FROM ratings) AS totalRatings
  `;

  db.query(sql, (err, result) => {
    if (err) {
      return res.status(500).json(err);
    }

    res.json(result[0]);
  });
};


// ======================
// CREATE ADMIN
// ======================

exports.createAdmin = async (req, res) => {
  try {
    const {
      name,
      email,
      address,
      password,
    } = req.body;

    const hashedPassword =
      await bcrypt.hash(password, 10);

    const sql = `
      INSERT INTO users
      (
        name,
        email,
        address,
        password,
        role
      )
      VALUES (?, ?, ?, ?, ?)
    `;

    db.query(
      sql,
      [
        name,
        email,
        address,
        hashedPassword,
        "SYSTEM_ADMIN",
      ],
      (err, result) => {
        if (err) {
          return res.status(500).json(err);
        }

        res.status(201).json({
          message:
            "Admin Created Successfully",
        });
      }
    );
  } catch (error) {
    res.status(500).json(error);
  }
};


// ======================
// CREATE USER
// ======================

exports.createUser = async (req, res) => {
  try {
    const {
      name,
      email,
      address,
      password,
    } = req.body;

    const hashedPassword =
      await bcrypt.hash(password, 10);

    const sql = `
      INSERT INTO users
      (
        name,
        email,
        address,
        password,
        role
      )
      VALUES (?, ?, ?, ?, ?)
    `;

    db.query(
      sql,
      [
        name,
        email,
        address,
        hashedPassword,
        "NORMAL_USER",
      ],
      (err, result) => {
        if (err) {
          return res.status(500).json(err);
        }

        res.status(201).json({
          message:
            "User Created Successfully",
        });
      }
    );
  } catch (error) {
    res.status(500).json(error);
  }
};


// ======================
// CREATE STORE
// ======================

exports.createStore = (req, res) => {
  const {
    name,
    email,
    address,
  } = req.body;

  const sql = `
    INSERT INTO stores
    (
      name,
      email,
      address
    )
    VALUES (?, ?, ?)
  `;

  db.query(
    sql,
    [
      name,
      email,
      address,
    ],
    (err, result) => {
      if (err) {
        return res.status(500).json(err);
      }

      res.status(201).json({
        message:
          "Store Created Successfully",
      });
    }
  );
};