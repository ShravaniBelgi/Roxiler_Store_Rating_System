const db = require("../config/db");

exports.getDashboardStats = (
  req,
  res
) => {
  const query = `
    SELECT
    (SELECT COUNT(*) FROM users) AS totalUsers,

    (SELECT COUNT(*) FROM stores) AS totalStores,

    (SELECT COUNT(*) FROM ratings) AS totalRatings
  `;

  db.query(query, (err, result) => {
    if (err)
      return res.status(500).json(err);

    res.json(result[0]);
  });
};