const db = require("../config/db");

exports.getUsers = (req, res) => {
  db.query(
    `
    SELECT
      id,
      name,
      email,
      address,
      role
    FROM users
    `,
    (err, result) => {
      if (err)
        return res.status(500).json(err);

      res.json(result);
    }
  );
};
exports.addUser = (req, res) => {
  const {
    name,
    email,
    address,
    password,
    role,
  } = req.body;

  db.query(
    `
    INSERT INTO users
    (
      name,
      email,
      address,
      password,
      role
    )
    VALUES (?, ?, ?, ?, ?)
    `,
    [
      name,
      email,
      address,
      password,
      role,
    ],
    (err, result) => {
      if (err)
        return res.status(500).json(err);

      res.json({
        success: true,
        message: "User Added Successfully",
      });
    }
  );
};
exports.getAllUsers = (req, res) => {
  db.query(
    `
    SELECT
      id,
      name,
      email,
      address,
      role
    FROM users
    ORDER BY id DESC
    `,
    (err, result) => {
      if (err)
        return res.status(500).json(err);

      res.json(result);
    }
  );
};
exports.getUserById = (req, res) => {
  db.query(
    "SELECT * FROM users WHERE id=?",
    [req.params.id],
    (err, result) => {
      if (err)
        return res.status(500).json(err);

      res.json(result[0]);
    }
  );
};
exports.getProfile = (req, res) => {
  const { id } = req.params;

  db.query(
    `
    SELECT
      id,
      name,
      email,
      address,
      role
    FROM users
    WHERE id = ?
    `,
    [id],
    (err, result) => {
      if (err) {
        return res.status(500).json(err);
      }

      if (result.length === 0) {
        return res.status(404).json({
          message: "User not found",
        });
      }

      res.status(200).json(result[0]);
    }
  );
};
exports.deleteUser = (req, res) => {
  db.query(
    "DELETE FROM users WHERE id=?",
    [req.params.id],
    (err) => {
      if (err)
        return res.status(500).json(err);

      res.json({
        message: "User Deleted",
      });
    }
  );
};