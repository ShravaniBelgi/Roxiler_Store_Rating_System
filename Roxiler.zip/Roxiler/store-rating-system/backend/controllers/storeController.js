const db = require("../config/db");
exports.getMyStore = (req, res) => {
  const ownerId = req.user.id;

  const sql = `
    SELECT
      id,
      name,
      email,
      address
    FROM stores
    WHERE owner_id = ?
  `;

  db.query(sql, [ownerId], (err, results) => {
    if (err) {
      return res.status(500).json(err);
    }

    if (results.length === 0) {
      return res.status(404).json({
        message: "Store not found",
      });
    }

    res.status(200).json(results[0]);
  });
};
exports.getStores = (req, res) => {
  db.query(
    `
    SELECT
      stores.*,

      ROUND(
        AVG(ratings.rating),
        1
      ) AS avgRating,

      COUNT(ratings.id)
      AS totalReviews

    FROM stores

    LEFT JOIN ratings
    ON stores.id = ratings.store_id

    GROUP BY stores.id
    `,
    (err, result) => {
      if (err)
        return res.status(500).json(err);

      res.json(result);
    }
  );
};

exports.getStoreById = (req, res) => {
  db.query(
    "SELECT * FROM stores WHERE id=?",
    [req.params.id],
    (err, result) => {
      if (err)
        return res.status(500).json(err);

      res.json(result[0]);
    }
  );
};

exports.addStore = (req, res) => {
  const {
    name,
    email,
    address,
    ownerId,
  } = req.body;

  db.query(
    `
    INSERT INTO stores
    (
      name,
      email,
      address,
      owner_id
    )
    VALUES (?, ?, ?, ?)
    `,
    [
      name,
      email,
      address,
      ownerId,
    ],
    (err) => {
      if (err)
        return res.status(500).json(err);

      res.json({
        success: true,
        message: "Store Added Successfully",
      });
    }
  );
};
exports.getAllStores = (req, res) => {
  db.query(
    `
    SELECT
      s.id,
      s.name,
      s.email,
      s.address,
      u.name AS ownerName
    FROM stores s
    LEFT JOIN users u
      ON s.owner_id = u.id
    `,
    (err, result) => {
      if (err)
        return res.status(500).json(err);

      res.json(result);
    }
  );
};
exports.deleteStore = (req, res) => {
  db.query(
    "DELETE FROM stores WHERE id=?",
    [req.params.id],
    (err) => {
      if (err)
        return res.status(500).json(err);

      res.json({
        message: "Store Deleted",
      });
    }
  );
};

exports.getStoresForUser = (req, res) => {
  const userId = req.user.id;

  const sql = `
    SELECT
      s.id,
      s.name,
      s.email,
      s.address,
      ROUND(AVG(r.rating),1) AS rating,
      COUNT(r.id) AS reviews,

      ur.rating AS userRating,
      ur.review AS userReview,

      CASE
        WHEN ur.id IS NOT NULL
        THEN TRUE
        ELSE FALSE
      END AS reviewedByCurrentUser

    FROM stores s

    LEFT JOIN ratings r
      ON s.id = r.store_id

    LEFT JOIN ratings ur
      ON s.id = ur.store_id
      AND ur.user_id = ?

    GROUP BY s.id
  `;

  db.query(sql, [userId], (err, result) => {
    if (err) {
      return res.status(500).json(err);
    }

    res.json(result);
  });
};