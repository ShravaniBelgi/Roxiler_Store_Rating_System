const db = require("../config/db");

exports.addRating = (req, res) => {
  const {
    user_id,
    store_id,
    rating,
    review,
  } = req.body;

  db.query(
    `
    INSERT INTO ratings
    (
      user_id,
      store_id,
      rating,
      review
    )
    VALUES(?,?,?,?)
    `,
    [
      user_id,
      store_id,
      rating,
      review,
    ],
    (err) => {
      if (err)
        return res.status(500).json(err);

      res.json({
        message:
          "Rating Submitted Successfully",
      });
    }
  );
};
exports.getAllRatings = (req, res) => {
  db.query(
    `
    SELECT
      r.id,
      r.rating,
      r.review,
      u.name AS userName,
      s.name AS storeName
    FROM ratings r
    JOIN users u
      ON r.user_id = u.id
    JOIN stores s
      ON r.store_id = s.id
    `,
    (err, result) => {
      if (err)
        return res.status(500).json(err);

      res.json(result);
    }
  );
};

exports.getStoreReviews = (
  req,
  res
) => {
  const storeId =
    req.params.storeId;

  db.query(
    `
    SELECT
      ratings.*,
      users.name

    FROM ratings

    JOIN users
    ON ratings.user_id =
    users.id

    WHERE store_id=?

    ORDER BY created_at DESC
    `,
    [storeId],
    (err, result) => {
      if (err)
        return res.status(500).json(err);

      res.json(result);
    }
  );
};