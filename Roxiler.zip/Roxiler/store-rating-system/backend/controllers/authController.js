const db = require("../config/db");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// REGISTER

exports.register = async (req, res) => {
  try {
    const {
      name,
      email,
      address,
      password,
      role,
    } = req.body;

    // Validation

    if (!name || !email || !address || !password || !role) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    // Check existing email

    db.query(
      "SELECT * FROM users WHERE email = ?",
      [email],
      async (err, result) => {
        if (err) {
          return res.status(500).json(err);
        }

        if (result.length > 0) {
          return res.status(400).json({
            success: false,
            message: "Email already exists",
          });
        }

        // Hash Password

        const hashedPassword =
          await bcrypt.hash(password, 10);

        db.query(
          `
          INSERT INTO users
          (
            name,
            email,
            address,
            password,
            role
          )
          VALUES (?, ?, ?, ?, ?)
          `,
          [
            name,
            email,
            address,
            hashedPassword,
            role,
          ],
          (err, result) => {
            if (err) {
              return res.status(500).json(err);
            }

            res.status(201).json({
              success: true,
              message:
                "User Registered Successfully",
            });
          }
        );
      }
    );
  } catch (error) {
    res.status(500).json(error);
  }
};

// LOGIN
exports.resetPassword = async (req, res) => {
  try {
    const {
      email,
      currentPassword,
      newPassword,
    } = req.body;

    db.query(
      "SELECT * FROM users WHERE email=?",
      [email],
      async (err, result) => {
        if (err)
          return res.status(500).json(err);

        if (result.length === 0) {
          return res.status(404).json({
            message: "User not found",
          });
        }

        const user = result[0];

        const isMatch =
          await bcrypt.compare(
            currentPassword,
            user.password
          );

        if (!isMatch) {
          return res.status(400).json({
            message:
              "Current password incorrect",
          });
        }

        const hashedPassword =
          await bcrypt.hash(
            newPassword,
            10
          );

        db.query(
          `
          UPDATE users
          SET password=?
          WHERE email=?
          `,
          [
            hashedPassword,
            email,
          ],
          (err) => {
            if (err)
              return res
                .status(500)
                .json(err);

            res.json({
              success: true,
              message:
                "Password Updated Successfully",
            });
          }
        );
      }
    );
  } catch (error) {
    res.status(500).json(error);
  }
};
exports.login = (req, res) => {

  try {
    const { email, password } = req.body;

    db.query(
      "SELECT * FROM users WHERE email = ?",
      [email],
      async (err, result) => {
        if (err) {
          return res.status(500).json(err);
        }

        if (result.length === 0) {
          return res.status(404).json({
            success: false,
            message: "User Not Found",
          });
        }

        const user = result[0];

        const isMatch =
          await bcrypt.compare(
            password,
            user.password
          );

        if (!isMatch) {
          return res.status(400).json({
            success: false,
            message: "Invalid Password",
          });
        }

        const token = jwt.sign(
          {
            id: user.id,
            role: user.role,
          },
          process.env.JWT_SECRET,
          {
            expiresIn: "1d",
          }
        );

        res.status(200).json({
          success: true,
          token,
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
          },
        });
      }
    );
  } catch (error) {
    res.status(500).json(error);
  }
};