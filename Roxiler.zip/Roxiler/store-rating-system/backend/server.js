require("dotenv").config();

const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/stores", require("./routes/storeRoutes"));
app.use("/api/ratings", require("./routes/ratingRoutes"));
app.use(
  "/api/dashboard",
  require("./routes/dashboardRoutes")
);
app.use(
  "/api/admin",
  require("./routes/adminRoutes")
);
app.use(
  "/api/users",
  require("./routes/userRoutes")
);

app.use(
  "/api/stores",
  require("./routes/storeRoutes")
);

app.use(
  "/api/ratings",
  require("./routes/ratingRoutes")
);
app.use(
  "/api/dashboard",
  require("./routes/dashboardRoutes")
);
app.get("/", (req, res) => {
  res.send("Store Rating API Running...");
});

app.listen(process.env.PORT, () => {
  console.log(
    `Server Running on Port ${process.env.PORT}`
  );
});