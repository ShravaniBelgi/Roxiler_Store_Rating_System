import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";
import Login from "./pages/Login";
import Register from "./pages/Register";
import UserDashboard from "./pages/user/Dashboard";
import StoreDashboard from "./pages/store/Dashboard";
import Dashboard from "./pages/admin/Dashboard";
import Users from "./pages/admin/Users";
import Stores from "./pages/admin/Stores";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />

        <Route path="/Register" element={<Register />} />
{/* 
        <Route
          path="/admin/dashboard"
          element={
            <ProtectedRoute role="SYSTEM_ADMIN">
              <Dashboard />
            </ProtectedRoute>
          }
        /> */}
<Route
  path="/admin/dashboard"
  element={
    <ProtectedRoute role="SYSTEM_ADMIN">
      <Dashboard />
    </ProtectedRoute>
  }
/>

<Route
  path="/admin/users"
  element={
    <ProtectedRoute role="SYSTEM_ADMIN">
      <Users />
    </ProtectedRoute>
  }
/>

<Route
  path="/admin/stores"
  element={
    <ProtectedRoute role="SYSTEM_ADMIN">
      <Stores />
    </ProtectedRoute>
  }
/>
        <Route
          path="/user/dashboard"
          element={
            <ProtectedRoute role="NORMAL_USER">
              <UserDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/store/dashboard"
          element={
            <ProtectedRoute role="STORE_OWNER">
              <StoreDashboard />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
