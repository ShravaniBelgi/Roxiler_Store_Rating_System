import React, { useState } from "react";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import API from "../services/api";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Grid,
  Paper,
  Typography,
  TextField,
  Button,
  InputAdornment,
  IconButton,
  Checkbox,
  FormControlLabel,
  Divider,
  Avatar,
} from "@mui/material";
import {
  Visibility,
  VisibilityOff,
  Storefront,
  Star,
  People,
  TrendingUp,
} from "@mui/icons-material";
import { motion } from "framer-motion";

const MotionPaper = motion(Paper);

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();
  const handleLogin = async () => {
    try {
      const response = await API.post("/auth/login", {
        email,
        password,
      });

      localStorage.setItem("token", response.data.token);

      localStorage.setItem("user", JSON.stringify(response.data.user));

      const role = response.data.user.role;

      if (role === "SYSTEM_ADMIN") {
        navigate("/admin/dashboard");
      }

      if (role === "NORMAL_USER") {
        navigate("/user/dashboard");
      }

      if (role === "STORE_OWNER") {
        navigate("/store/dashboard");
      }
    } catch (error) {
      alert(error.response?.data?.message || "Login Failed");
    }
  };
  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#F8FAFC",
        "@keyframes float": {
          "0%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-20px)" },
          "100%": { transform: "translateY(0px)" },
        },
      }}
    >
      <Grid container sx={{ minHeight: "100vh" }}>
        <Grid
          item
          xs={0}
          md={12}
          sx={{
            display: { xs: "none", md: "flex" },
            flexDirection: "column",
            justifyContent: "center",
            px: 10,
            background: "linear-gradient(135deg,#0F172A,#111827,#1E293B)",
            position: "relative",
            overflow: "hidden",
          }}
        >
          <Box
            sx={{
              position: "absolute",
              top: "10%",
              left: "15%",
              fontSize: 40,
              color: "#FBBF24",
              filter: "drop-shadow(0 0 20px #FBBF24)",
              animation: "float 6s ease-in-out infinite",
            }}
          >
            ⭐
          </Box>

          <Box
            sx={{
              position: "absolute",
              top: "25%",
              right: "15%",
              fontSize: 35,
              color: "#FBBF24",
              filter: "drop-shadow(0 0 20px #FBBF24)",
              animation: "float 7s ease-in-out infinite",
            }}
          >
            ⭐
          </Box>

          <Box
            sx={{
              position: "absolute",
              width: 250,
              height: 250,
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "30px",
              transform: "rotate(45deg)",
              top: 80,
              right: -80,
            }}
          />
          <Box
            sx={{
              position: "absolute",
              width: 180,
              height: 180,
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "50%",
              bottom: 100,
              left: -50,
            }}
          />
          <Box
            sx={{
              position: "absolute",
              width: 120,
              height: 120,
              background: "linear-gradient(135deg,#2563EB20,#7C3AED20)",
              clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
              bottom: 50,
              right: 200,
            }}
          />

          <motion.div
            initial={{ opacity: 0, x: -60 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
          >
            <Typography variant="h2" fontWeight={800} sx={{ color: "#CBD5E1" }}>
              Store Rating
            </Typography>
            <Typography variant="h3" fontWeight={700} sx={{ color: "#CBD5E1" }}>
              Management Platform
            </Typography>

            <Box sx={{ display: "flex", alignItems: "center", mt: 3, gap: 1 }}>
              ⭐⭐⭐⭐⭐
              <Typography sx={{ color: "#CBD5E1", ml: 2, fontWeight: 600 }}>
                Trusted by 5,000+ Users
              </Typography>
            </Box>

            <Typography
              sx={{
                mt: 3,
                color: "#CBD5E1",
                maxWidth: 650,
                fontSize: "18px",
                lineHeight: 1.8,
              }}
            >
              Manage stores, track ratings, analyze customer feedback and
              monitor business performance through a powerful dashboard.
            </Typography>
          </motion.div>

          <Grid container spacing={3} sx={{ mt: 4 }}>
            {[
              ["Total Stores", "1,284", <Storefront />, "#DBEAFE", "#2563EB"],
              ["Active Users", "5,632", <People />, "#DCFCE7", "#16A34A"],
              ["Avg Rating", "4.8", <Star />, "#FEF3C7", "#D97706"],
            ].map((c, i) => (
              <Grid item xs={4} key={i}>
                <Paper
                  sx={{
                    p: 3,
                    borderRadius: 4,
                    boxShadow: "0 10px 30px rgba(0,0,0,0.05)",
                  }}
                >
                  <Avatar sx={{ bgcolor: c[3], color: c[4], mb: 2 }}>
                    {c[2]}
                  </Avatar>
                  <Typography color="text.secondary">{c[0]}</Typography>
                  <Typography variant="h4" fontWeight={700}>
                    {c[1]}
                  </Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Grid>

        <Grid
          item
          xs={12}
          md={12}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            bgcolor: "#FFFFFF",
          }}
        >
          <MotionPaper
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            elevation={0}
            sx={{
              width: "100%",
              maxWidth: 400,
              p: 5,
              borderRadius: 5,
              border: "1px solid #E2E8F0",
              boxShadow: "0px 20px 60px rgba(15,23,42,0.08)",
            }}
          >
            <Box textAlign="center">
              <Avatar
                sx={{ width: 70, height: 70, mx: "auto", bgcolor: "#2563EB" }}
              >
                <Storefront />
              </Avatar>
              <Typography variant="h4" fontWeight="700" mt={2}>
                Welcome Back
              </Typography>
              <Typography color="text.secondary" mt={1}>
                Sign in to continue
              </Typography>
            </Box>

            <TextField
              fullWidth
              label="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <TextField
              fullWidth
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <FormControl fullWidth margin="normal">
              <InputLabel>Select Role</InputLabel>

              <Select
                value={role}
                label="Select Role"
                onChange={(e) => setRole(e.target.value)}
                sx={{
                  borderRadius: "14px",

                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#E2E8F0",
                  },

                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "#2563EB",
                  },
                }}
              >
                <MenuItem value="admin">System Administrator</MenuItem>

                <MenuItem value="user">Normal User</MenuItem>

                <MenuItem value="owner">Store Owner</MenuItem>
              </Select>
            </FormControl>
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              mt={1}
            >
              <FormControlLabel control={<Checkbox />} label="Remember me" />
              <Button variant="text" size="small">
                Forgot Password?
              </Button>
            </Box>

            <Button fullWidth variant="contained" onClick={handleLogin}>
              Login
            </Button>

            <Divider sx={{ my: 3 }}>OR</Divider>

            <Button
              fullWidth
              variant="outlined"
              size="large"
              onClick={() => navigate("/register")}
              sx={{
                height: 56,
                borderRadius: 3,
                textTransform: "none",
                fontWeight: 600,
              }}
            >
              Create Account
            </Button>
          </MotionPaper>
        </Grid>
      </Grid>
    </Box>
  );
}
