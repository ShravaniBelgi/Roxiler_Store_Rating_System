import React, { useState,useEffect } from "react";
import API from "../../services/api";
import {
  Box,
  Grid,
  Paper,
  Typography,
  Avatar,
  TextField,
  InputAdornment,
  Chip,
  Rating,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";

import {
  Search,
  Person,
  Storefront,
  LocationOn,
  Email,
} from "@mui/icons-material";

import Sidebar from "../../components/Sidebar";
import Navbar from "../../components/Navbar";

const users = [
  {
    id: 1,
    name: "John Doe",
    email: "john@gmail.com",
    address: "Pune",
    role: "Store Owner",
    store: {
      name: "Electronics Hub",
      rating: 4.8,
      reviews: 320,
    },
  },
  {
    id: 2,
    name: "Sarah Smith",
    email: "sarah@gmail.com",
    address: "Mumbai",
    role: "Normal User",
  },
  {
    id: 3,
    name: "Admin User",
    email: "admin@gmail.com",
    address: "Delhi",
    role: "System Administrator",
  },
  {
    id: 4,
    name: "Michael Johnson",
    email: "michael@gmail.com",
    address: "Bangalore",
    role: "Store Owner",
    store: {
      name: "Fashion World",
      rating: 4.5,
      reviews: 180,
    },
  },
];

export default function Users() {
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [users, setUsers] = useState([]);
      const fetchUsers = async () => {
      try {
        const response = await API.get("/users");

        setUsers(response.data);
      } catch (error) {
        console.log(error);
      }
    };

   useEffect(() => {
      fetchUsers();
    }, []);
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(search.toLowerCase()) ||
      user.email.toLowerCase().includes(search.toLowerCase());

    const matchesRole = roleFilter === "" || user.role === roleFilter;

   


    return matchesSearch && matchesRole;
  });

  return (
    <Box
      sx={{
        display: "flex",
        bgcolor: "#F8FAFC",
        minHeight: "100vh",
      }}
    >
      <Sidebar />

      <Box
        sx={{
          ml: "280px",
          width: "100%",
          p: 4,
        }}
      >
        <Navbar />

        {/* Header */}

        <Paper
          sx={{
            mt: 3,
            p: 4,
            borderRadius: 5,
            background: "linear-gradient(135deg,#2563EB,#3B82F6)",
            color: "#fff",
          }}
        >
          <Typography variant="h4" fontWeight="700">
            Users Management
          </Typography>

          <Typography mt={1}>Manage platform users and store owners</Typography>
        </Paper>

        {/* Filters */}

        <Paper
          sx={{
            mt: 3,
            p: 3,
            borderRadius: 4,
            background: "rgba(255,255,255,0.8)",
            backdropFilter: "blur(20px)",
          }}
        >
          <Grid container spacing={2}>
            <Grid item xs={12} md={8}>
              <TextField
                fullWidth
                placeholder="Search by Name or Email"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Search />
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>

            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Filter By Role</InputLabel>

                <Select
                  value={roleFilter}
                  label="Filter By Role"
                  onChange={(e) => setRoleFilter(e.target.value)}
                >
                  <MenuItem value="">All Roles</MenuItem>

                  <MenuItem value="System Administrator">
                    System Administrator
                  </MenuItem>

                  <MenuItem value="Store Owner">Store Owner</MenuItem>

                  <MenuItem value="Normal User">Normal User</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </Paper>

        {/* User Cards */}

        <Grid container spacing={3} sx={{ mt: 1 }}>
          {filteredUsers.map((user) => (
            <Grid item xs={12} md={6} lg={4} key={user.id}>
              <Paper
                sx={{
                  p: 3,
                  borderRadius: 5,
                  background: "rgba(255,255,255,0.85)",
                  backdropFilter: "blur(20px)",

                  border: "1px solid rgba(255,255,255,0.4)",

                  boxShadow: "0 15px 35px rgba(0,0,0,0.08)",

                  transition: "0.3s",

                  "&:hover": {
                    transform: "translateY(-8px)",
                  },
                }}
              >
                <Avatar
                  sx={{
                    width: 70,
                    height: 70,
                    background: "linear-gradient(135deg,#2563EB,#60A5FA)",
                    mb: 2,
                  }}
                >
                  <Person />
                </Avatar>

                <Typography variant="h6" fontWeight="700">
                  {user.name}
                </Typography>

                <Box display="flex" alignItems="center" gap={1} mt={1}>
                  <Email fontSize="small" color="primary" />

                  <Typography color="text.secondary">{user.email}</Typography>
                </Box>

                <Box display="flex" alignItems="center" gap={1} mt={1}>
                  <LocationOn fontSize="small" color="error" />

                  <Typography>{user.address}</Typography>
                </Box>

                {/* Store Owner Section */}

                {user.role === "Store Owner" && user.store && (
                  <Paper
                    elevation={0}
                    sx={{
                      mt: 2,
                      p: 2,
                      borderRadius: 3,
                      bgcolor: "#F8FAFC",
                      border: "1px solid #E2E8F0",
                    }}
                  >
                    <Box display="flex" alignItems="center" gap={1} mb={1}>
                      <Storefront color="primary" />

                      <Typography fontWeight="700" color="primary">
                        {user.store.name}
                      </Typography>
                    </Box>

                    <Box
                      display="flex"
                      justifyContent="space-between"
                      alignItems="center"
                    >
                      <Box>
                        <Rating
                          value={user.store.rating}
                          precision={0.1}
                          readOnly
                          size="small"
                        />

                        <Typography variant="body2" color="text.secondary">
                          {user.store.rating} / 5
                        </Typography>
                      </Box>

                      <Chip
                        label={`${user.store.reviews} Reviews`}
                        color="warning"
                        size="small"
                      />
                    </Box>
                  </Paper>
                )}

                <Chip
                  label={user.role}
                  color={
                    user.role === "System Administrator"
                      ? "secondary"
                      : user.role === "Store Owner"
                        ? "success"
                        : "primary"
                  }
                  sx={{ mt: 2 }}
                />
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Box>
  );
}
