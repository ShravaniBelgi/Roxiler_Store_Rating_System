import React, { useState,useEffect } from "react";

import {
  Box,
  Typography,
  Paper,
  Grid,
  Avatar,
  TextField,
  InputAdornment,
  Rating,
  Chip,
} from "@mui/material";
import API from "../../services/api";
import {
  Search,
  Storefront,
  LocationOn,
  Email,
} from "@mui/icons-material";

import { motion } from "framer-motion";

import Sidebar from "../../components/Sidebar";
import Navbar from "../../components/Navbar";

const MotionPaper = motion(Paper);

export default function Stores() {
  const [search, setSearch] = useState("");

 const [stores, setStores] =
  useState([]);

  const fetchStores = async () => {
  try {
    const response =
      await API.get("/stores");

    setStores(response.data);
  } catch (error) {
    console.log(error);
  }
};
useEffect(() => {
  fetchStores();
}, []);

 const filteredStores =
  stores.filter((store) => {
    const searchText =
      search.toLowerCase();

    return (
      store.name
        .toLowerCase()
        .includes(searchText) ||
      store.email
        .toLowerCase()
        .includes(searchText) ||
      store.address
        .toLowerCase()
        .includes(searchText)
    );
  });

  return (
    <Box
      sx={{
        display: "flex",
        bgcolor: "#F8FAFC",
        minHeight: "100vh",
      }}
    >
      <Sidebar />

      <Box
        sx={{
          ml: "280px",
          width: "100%",
          p: 4,
        }}
      >
        <Navbar />

        {/* HEADER */}

        <Paper
          sx={{
            mt: 3,
            p: 4,
            borderRadius: 5,
            background:
              "linear-gradient(135deg,#2563EB,#3B82F6)",
            color: "#fff",
          }}
        >
          <Typography
            variant="h4"
            fontWeight="700"
          >
            Store Management
          </Typography>

          <Typography mt={1}>
            View and manage all registered stores.
          </Typography>
        </Paper>

        {/* SEARCH */}

        <Paper
          sx={{
            mt: 3,
            p: 3,
            borderRadius: 4,
          }}
        >
          <TextField
            fullWidth
            placeholder="Search Store..."
            value={search}
            onChange={(e) =>
              setSearch(e.target.value)
            }
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
          />
        </Paper>

        {/* STORE CARDS */}

        <Grid
          container
          spacing={3}
          sx={{ mt: 1 }}
        >
          {filteredStores.map((store) => (
            <Grid
              item
              xs={12}
              md={6}
              lg={4}
              key={store.id}
            >
              <MotionPaper
                whileHover={{
                  y: -10,
                  scale: 1.02,
                }}
                transition={{
                  duration: 0.3,
                }}
                sx={{
                  p: 3,
                  borderRadius: "24px",

                  background:
                    "rgba(255,255,255,0.75)",

                  backdropFilter:
                    "blur(20px)",

                  border:
                    "1px solid rgba(255,255,255,0.3)",

                  boxShadow:
                    "0 20px 40px rgba(0,0,0,0.08)",

                  overflow: "hidden",
                  position: "relative",
                }}
              >
                {/* Glow Effect */}

                <Box
                  sx={{
                    position: "absolute",
                    top: -60,
                    right: -60,
                    width: 140,
                    height: 140,
                    borderRadius: "50%",
                    background:
                      "linear-gradient(135deg,#3B82F6,#60A5FA)",
                    opacity: 0.1,
                  }}
                />

                <Box
                  display="flex"
                  alignItems="center"
                  gap={2}
                >
                  <Avatar
                    sx={{
                      width: 70,
                      height: 70,
                      background:
                        "linear-gradient(135deg,#2563EB,#60A5FA)",
                    }}
                  >
                    <Storefront />
                  </Avatar>

                  <Box>
                    <Typography
                      variant="h6"
                      fontWeight="700"
                    >
                      {store.name}
                    </Typography>

                    
                  </Box>
                </Box>

                <Box mt={3}>
                  <Box
                    display="flex"
                    gap={1}
                    mb={2}
                  >
                    <Email
                      color="primary"
                    />
                    <Typography>
                      {store.email}
                    </Typography>
                  </Box>

                  <Box
                    display="flex"
                    gap={1}
                    mb={2}
                  >
                    <LocationOn
                      color="error"
                    />
                    <Typography>
                      {store.address}
                    </Typography>
                  </Box>

                  <Box
                    display="flex"
                    justifyContent="space-between"
                    alignItems="center"
                    mt={3}
                  >
                    <Box>
                      <Rating
                        value={store.rating}
                        precision={0.1}
                        readOnly
                      />

                      <Typography
                        color="text.secondary"
                      >
                        {store.rating} / 5
                      </Typography>
                    </Box>

                    <Chip
                      label={`${store.reviews} Reviews`}
                      sx={{
                        bgcolor:
                          "#EFF6FF",
                        color:
                          "#2563EB",
                        fontWeight:
                          600,
                      }}
                    />
                  </Box>
                </Box>
              </MotionPaper>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Box>
  );
}