import React from "react";
import Sidebar from "../../components/Sidebar";
import Navbar from "../../components/Navbar";
import API from "../../services/api";
import { useState,useEffect } from "react";
import {
  Dialog,
  DialogContent,
  Fade,
  TextField,
  Button,
  Stack,
  MenuItem,
} from "@mui/material";

import PersonAddIcon from "@mui/icons-material/PersonAdd";
import AddBusinessIcon from "@mui/icons-material/AddBusiness";

import {
  Box,
  Grid,
  Paper,
  Typography,
  Avatar,
  IconButton,
  LinearProgress,
} from "@mui/material";

import {
  People,
  Storefront,
  Star,
  TrendingUp,
  Notifications,
  MoreVert,
} from "@mui/icons-material";

import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

import { motion } from "framer-motion";

const chartData = [
  { month: "Jan", ratings: 120 },
  { month: "Feb", ratings: 180 },
  { month: "Mar", ratings: 240 },
  { month: "Apr", ratings: 320 },
  { month: "May", ratings: 420 },
  { month: "Jun", ratings: 520 },
];

export default function Dashboard() {
  const [dashboardStats, setDashboardStats] = useState({
    totalUsers: 0,
    totalStores: 0,
    totalRatings: 0,
  });
const fetchDashboardStats = async () => {
  try {
    const response = await API.get("/dashboard/stats");

    setDashboardStats(response.data);
  } catch (error) {
    console.log(error);
  }
};

useEffect(() => {
  fetchDashboardStats();
}, []);
  const [openAdminModal, setOpenAdminModal] = useState(false);
  const [openUserModal, setOpenUserModal] = useState(false);
  const [openStoreModal, setOpenStoreModal] = useState(false);
//   useEffect(() => {
//   fetchStats();
// }, []);
const [adminForm, setAdminForm] = useState({
  name: "",
  email: "",
  address: "",
  password: "",
  role: "SYSTEM_ADMIN",
});

const [userForm, setUserForm] = useState({
  name: "",
  email: "",
  address: "",
  password: "",
  role: "NORMAL_USER",
});

const [storeForm, setStoreForm] = useState({
  name: "",
  email: "",
  address: "",
});
const handleCreateAdmin = async () => {
  try {
    await API.post("/users/add", adminForm);

    alert("Admin Created Successfully");

    setOpenAdminModal(false);

    fetchDashboardStats();
  } catch (error) {
    console.log(error);
  }
};

const handleCreateUser = async () => {
  try {
    await API.post("/users/add", userForm);

    alert("User Created Successfully");

    setOpenUserModal(false);

    fetchDashboardStats();
  } catch (error) {
    console.log(error);
  }
};

const handleCreateStore = async () => {
  try {
    await API.post("/stores/add", storeForm);

    alert("Store Created Successfully");

    setOpenStoreModal(false);

    fetchDashboardStats();
  } catch (error) {
    console.log(error);
  }
};
  const stats = [
    {
      title: "Total Users",
      value: dashboardStats.totalUsers,
      icon: <People />,
      gradient: "linear-gradient(135deg,#3B82F6,#2563EB)",
    },
    {
      title: "Total Stores",
      value: dashboardStats.totalStores,
      icon: <Storefront />,
      gradient: "linear-gradient(135deg,#22C55E,#16A34A)",
    },
    {
      title: "Submitted Ratings",
      value: dashboardStats.totalRatings,
      icon: <Star />,
      gradient: "linear-gradient(135deg,#F59E0B,#D97706)",
    },
  ];

  useEffect(() => {
    fetchDashboardStats();
  }, []);

// const fetchDashboardStats = async () => {
//   try {
//     const response = await API.get("/dashboard/stats");

//     setDashboardStats(response.data);
//   } catch (error) {
//     console.log(error);
//   }
// };

useEffect(() => {
  fetchDashboardStats();
}, []);

  return (
    <Box
      sx={{
        display: "flex",
        bgcolor: "#F8FAFC",
        minHeight: "100vh",
      }}
    >
      <Sidebar />

      <Box
        sx={{
          ml: "280px",
          width: "100%",
          p: 4,
        }}
      >
        <Navbar />

        {/* Dashboard Content Starts Here */}

        <Box
          sx={{
            mt: 4,
            mb: 4,
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              md: "repeat(3,1fr)",
            },
            gap: 3,
          }}
        >
          {/* ADD ADMIN */}

          <Paper
            onClick={() => setOpenAdminModal(true)}
            sx={{
              p: 3,
              cursor: "pointer",
              borderRadius: "24px",
              background: "linear-gradient(135deg,#8B5CF6,#7C3AED)",
              color: "#fff",
              transition: "0.3s",

              "&:hover": {
                transform: "translateY(-8px)",
                boxShadow: "0 20px 40px rgba(124,58,237,0.35)",
              },
            }}
          >
            <Stack direction="row" spacing={2}>
              <PersonAddIcon sx={{ fontSize: 42 }} />

              <Box>
                <Typography variant="h6">Add Admin</Typography>

                <Typography variant="body2">
                  Create system administrator
                </Typography>
              </Box>
            </Stack>
          </Paper>

          {/* ADD USER */}

          <Paper
            onClick={() => setOpenUserModal(true)}
            sx={{
              p: 3,
              cursor: "pointer",
              borderRadius: "24px",
              background: "linear-gradient(135deg,#3B82F6,#2563EB)",
              color: "#fff",
              transition: "0.3s",

              "&:hover": {
                transform: "translateY(-8px)",
                boxShadow: "0 20px 40px rgba(37,99,235,0.35)",
              },
            }}
          >
            <Stack direction="row" spacing={2}>
              <PersonAddIcon sx={{ fontSize: 42 }} />

              <Box>
                <Typography variant="h6">Add User</Typography>

                <Typography variant="body2">Create platform user</Typography>
              </Box>
            </Stack>
          </Paper>

          {/* ADD STORE */}

          <Paper
            onClick={() => setOpenStoreModal(true)}
            sx={{
              p: 3,
              cursor: "pointer",
              borderRadius: "24px",
              background: "linear-gradient(135deg,#22C55E,#16A34A)",
              color: "#fff",
              transition: "0.3s",

              "&:hover": {
                transform: "translateY(-8px)",
                boxShadow: "0 20px 40px rgba(22,163,74,0.35)",
              },
            }}
          >
            <Stack direction="row" spacing={2}>
              <AddBusinessIcon sx={{ fontSize: 42 }} />

              <Box>
                <Typography variant="h6">Add Store</Typography>

                <Typography variant="body2">Register new store</Typography>
              </Box>
            </Stack>
          </Paper>
        </Box>
        {/* KPI Cards, Charts, Recent Activities etc. */}
        <Grid container spacing={4} sx={{ mt: 1 }}>
          {stats.map((item, index) => (
            <Grid item xs={12} md={4} key={index}>
              <motion.div
                whileHover={{
                  y: -10,
                  scale: 1.02,
                }}
                transition={{
                  duration: 0.3,
                }}
              >
                <Paper
                  elevation={0}
                  sx={{
                    p: 4,
                    borderRadius: "24px",

                    background: "rgba(255,255,255,0.65)",

                    backdropFilter: "blur(20px)",

                    border: "1px solid rgba(255,255,255,0.4)",

                    boxShadow: "0 20px 40px rgba(0,0,0,0.08)",

                    position: "relative",
                    overflow: "hidden",
                  }}
                >
                  <Box
                    sx={{
                      position: "absolute",
                      top: -40,
                      right: -40,
                      width: 120,
                      height: 120,
                      borderRadius: "50%",
                      background: item.gradient,
                      opacity: 0.15,
                    }}
                  />

                  <Box
                    display="flex"
                    justifyContent="space-between"
                    alignItems="center"
                  >
                    <Box>
                      <Typography
                        sx={{
                          color: "#64748B",
                          fontWeight: 500,
                        }}
                      >
                        {item.title}
                      </Typography>

                      <Typography
                        variant="h3"
                        fontWeight="800"
                        sx={{
                          mt: 1,
                          color: "#0F172A",
                        }}
                      >
                        {item.value}
                      </Typography>

                      <Typography
                        sx={{
                          color: "#22C55E",
                          mt: 1,
                          fontWeight: 600,
                        }}
                      >
                        +12% this month
                      </Typography>
                    </Box>

                    <Avatar
                      sx={{
                        width: 72,
                        height: 72,
                        background: item.gradient,

                        boxShadow: "0 10px 25px rgba(0,0,0,0.15)",
                      }}
                    >
                      {item.icon}
                    </Avatar>
                  </Box>
                </Paper>
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Box>
      <Dialog
        open={openUserModal}
        onClose={() => setOpenUserModal(false)}
        maxWidth="sm"
        fullWidth
        TransitionComponent={Fade}
      >
        <DialogContent
          sx={{
            p: 5,

            background: "rgba(255,255,255,0.9)",

            backdropFilter: "blur(20px)",
          }}
        >
          <Typography variant="h4" fontWeight="700" mb={3}>
            Create User
          </Typography>

<TextField
  fullWidth
  label="Full Name"
  margin="normal"
  value={userForm.name}
  onChange={(e) =>
    setUserForm({
      ...userForm,
      name: e.target.value,
    })
  }
/>
<TextField
  fullWidth
  label="Email"
  margin="normal"
  value={userForm.email}
  onChange={(e) =>
    setUserForm({
      ...userForm,
      email: e.target.value,
    })
  }
/>
<TextField
  fullWidth
  label="Address"
  margin="normal"
  value={userForm.address}
  onChange={(e) =>
    setUserForm({
      ...userForm,
      address: e.target.value,
    })
  }
/>
          <TextField
  fullWidth
  label="Password"
  type="password"
  margin="normal"
  value={userForm.password}
  onChange={(e) =>
    setUserForm({
      ...userForm,
      password: e.target.value,
    })
  }
/>

          <Button
  variant="contained"
  fullWidth
  onClick={handleCreateUser}
  sx={{
    mt: 3,
    height: 55,
    borderRadius: 3,
  }}
>
  Create User
</Button>
        </DialogContent>
      </Dialog>
      <Dialog
        open={openStoreModal}
        onClose={() => setOpenStoreModal(false)}
        maxWidth="sm"
        fullWidth
        TransitionComponent={Fade}
      >
        <DialogContent
          sx={{
            p: 5,

            background: "rgba(255,255,255,0.9)",

            backdropFilter: "blur(20px)",
          }}
        >
          <Typography variant="h4" fontWeight="700" mb={3}>
            Register Store
          </Typography>

<TextField
  fullWidth
  label="Store Name"
  margin="normal"
  value={storeForm.name}
  onChange={(e) =>
    setStoreForm({
      ...storeForm,
      name: e.target.value,
    })
  }
/>
<TextField
  fullWidth
  label="Email"
  margin="normal"
  value={storeForm.email}
  onChange={(e) =>
    setStoreForm({
      ...storeForm,
      email: e.target.value,
    })
  }
/>
<TextField
  fullWidth
  label="Address"
  margin="normal"
  value={storeForm.address}
  onChange={(e) =>
    setStoreForm({
      ...storeForm,
      address: e.target.value,
    })
  }
/>
          <Button
  variant="contained"
  color="success"
  fullWidth
  onClick={handleCreateStore}
  sx={{
    mt: 3,
    height: 55,
    borderRadius: 3,
  }}
>
  Create Store
</Button>
      </DialogContent>
      </Dialog>

      <Dialog
        open={openAdminModal}
        onClose={() => setOpenAdminModal(false)}
        maxWidth="sm"
        fullWidth
        TransitionComponent={Fade}
      >
        <DialogContent
          sx={{
            p: 5,
            background: "rgba(255,255,255,0.95)",
            backdropFilter: "blur(20px)",
            borderRadius: "20px",
          }}
        >
          <Typography variant="h4" fontWeight="700" mb={3} color="#7C3AED">
            Create Admin
          </Typography>

<TextField
  fullWidth
  label="Full Name"
  margin="normal"
  value={adminForm.name}
  onChange={(e) =>
    setAdminForm({
      ...adminForm,
      name: e.target.value,
    })
  }
/>
<TextField
  fullWidth
  label="Email Address"
  margin="normal"
  value={adminForm.email}
  onChange={(e) =>
    setAdminForm({
      ...adminForm,
      email: e.target.value,
    })
  }
/>
<TextField
  fullWidth
  label="Address"
  margin="normal"
  value={adminForm.address}
  onChange={(e) =>
    setAdminForm({
      ...adminForm,
      address: e.target.value,
    })
  }
/>
          <TextField
  fullWidth
  label="Password"
  type="password"
  margin="normal"
  value={adminForm.password}
  onChange={(e) =>
    setAdminForm({
      ...adminForm,
      password: e.target.value,
    })
  }
/>

       <Button
  fullWidth
  variant="contained"
  onClick={handleCreateAdmin}
  sx={{
    mt: 3,
    height: 56,
    borderRadius: 3,
    background: "linear-gradient(135deg,#8B5CF6,#7C3AED)",
    fontWeight: 700,
  }}
>
  Create Admin
</Button>
        </DialogContent>
      </Dialog>
    </Box>
  );
}
