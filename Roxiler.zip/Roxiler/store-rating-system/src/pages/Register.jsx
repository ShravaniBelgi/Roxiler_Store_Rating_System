import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";

import {
  Box,
  Grid,
  Paper,
  Typography,
  TextField,
  Button,
  Avatar,
  InputAdornment,
  IconButton,
  Divider,
    MenuItem,
} from "@mui/material";

import {
  PersonAdd,
  Visibility,
  VisibilityOff,
  Storefront,
} from "@mui/icons-material";

import { motion } from "framer-motion";

const MotionPaper = motion(Paper);

function Register() {
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    address: "",
    password: "",
    role:""
  });
      const [role, setRole] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };
  const validateForm = () => {
    let newErrors = {};

    // Name Validation
    if (formData.name.length < 20 || formData.name.length > 60) {
      newErrors.name = "Name must be between 20 and 60 characters";
    }

    // Email Validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(formData.email)) {
      newErrors.email = "Enter a valid email address";
    }

    // Address Validation
    if (formData.address.length > 400) {
      newErrors.address = "Address cannot exceed 400 characters";
    }

    // Password Validation
    const passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*(),.?":{}|<>]).{8,16}$/;

    if (!passwordRegex.test(formData.password)) {
      newErrors.password =
        "Password must be 8-16 characters with 1 uppercase letter and 1 special character";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };
  const handleRegister = async () => {
    try {
      const response = await API.post("/auth/register", {
        name: formData.name,
        email: formData.email,
        address: formData.address,
        password: formData.password,
        role: role,
      });

      alert(response.data.message);

      navigate("/");
    } catch (error) {
      alert(error.response?.data?.message || "Registration Failed");
    }
  };
  const [errors, setErrors] = useState({});
  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#F8FAFC",

        "@keyframes float": {
          "0%": {
            transform: "translateY(0px)",
          },
          "50%": {
            transform: "translateY(-15px)",
          },
          "100%": {
            transform: "translateY(0px)",
          },
        },
      }}
    >
      <Grid container sx={{ minHeight: "100vh" }}>
        {/* LEFT SECTION */}

        <Grid
          item
          xs={0}
          md={6}
          sx={{
            display: {
              xs: "none",
              md: "flex",
            },

            flexDirection: "column",
            justifyContent: "center",
            px: 8,

            background: "linear-gradient(135deg,#0F172A,#111827,#1E293B)",

            position: "relative",
            overflow: "hidden",
          }}
        >
          {/* Floating Stars */}

          <Box
            sx={{
              position: "absolute",
              top: "10%",
              left: "12%",
              fontSize: 40,
              color: "#FBBF24",
              animation: "float 6s ease-in-out infinite",
            }}
          >
            ⭐
          </Box>

          <Box
            sx={{
              position: "absolute",
              top: "25%",
              right: "15%",
              fontSize: 30,
              color: "#FBBF24",
              animation: "float 8s ease-in-out infinite",
            }}
          >
            ⭐
          </Box>

          {/* Shapes */}

          <Box
            sx={{
              position: "absolute",
              width: 260,
              height: 260,
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "30px",
              transform: "rotate(45deg)",
              top: 50,
              right: -80,
            }}
          />

          <Box
            sx={{
              position: "absolute",
              width: 180,
              height: 180,
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "50%",
              bottom: 100,
              left: -50,
            }}
          />

          <motion.div
            initial={{
              opacity: 0,
              x: -50,
            }}
            animate={{
              opacity: 1,
              x: 0,
            }}
            transition={{
              duration: 0.8,
            }}
          >
            <Typography
              variant="h2"
              fontWeight={800}
              color="#FFFFFF"
              sx={{ mt: 3, color: "#CBD5E1" }}
            >
              Join Store
            </Typography>

            <Typography
              variant="h3"
              fontWeight={700}
              color="#60A5FA"
              sx={{ mt: 3, color: "#CBD5E1" }}
            >
              Rating Platform
            </Typography>

            <Typography
              sx={{
                mt: 3,
                color: "#CBD5E1",
                fontSize: 18,
                lineHeight: 1.8,
                maxWidth: 550,
              }}
            >
              Register and manage stores, customer reviews and ratings from one
              powerful platform.
            </Typography>

            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                mt: 4,
              }}
            >
              <Typography
                sx={{
                  color: "#FBBF24",
                  fontSize: 24,
                }}
              >
                ⭐⭐⭐⭐⭐
              </Typography>

              <Typography
                sx={{
                  ml: 2,
                  color: "#CBD5E1",
                }}
              >
                Trusted by thousands of users
              </Typography>
            </Box>
          </motion.div>

          <Paper
            sx={{
              mt: 5,
              p: 4,
              borderRadius: 5,
            }}
          >
            <Typography variant="h6" fontWeight={700}>
              Platform Features
            </Typography>

            <Typography mt={2}>✅ Store Management</Typography>

            <Typography mt={1}>✅ Customer Ratings</Typography>

            <Typography mt={1}>✅ Analytics Dashboard</Typography>

            <Typography mt={1}>✅ Performance Tracking</Typography>
          </Paper>
        </Grid>

        {/* RIGHT SECTION */}

        <Grid
          item
          xs={12}
          md={6}
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            bgcolor: "#FFFFFF",
          }}
        >
          <MotionPaper
            initial={{
              opacity: 0,
              y: 50,
            }}
            animate={{
              opacity: 1,
              y: 0,
            }}
            transition={{
              duration: 0.7,
            }}
            elevation={0}
            sx={{
              width: "100%",
              maxWidth: 450,
              p: 5,
              borderRadius: 5,
              border: "1px solid #E2E8F0",
              boxShadow: "0 20px 60px rgba(15,23,42,0.08)",
            }}
          >
            <Box textAlign="center">
              <Avatar
                sx={{
                  width: 70,
                  height: 70,
                  mx: "auto",
                  bgcolor: "#2563EB",
                }}
              >
                <PersonAdd />
              </Avatar>

              <Typography variant="h4" fontWeight={700} mt={2} variant="contained" onClick={handleRegister}>
                Create Account
              </Typography>

              

              <Typography color="text.secondary" mt={1}>
                Start your journey today
              </Typography>
            </Box>

            <TextField
              fullWidth
              label="Full Name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              error={!!errors.name}
              helperText={errors.name}
              margin="normal"
              sx={{ mt: 4 }}
            />

            <TextField
              fullWidth
              label="Email Address"
              name="email"
              value={formData.email}
              onChange={handleChange}
              error={!!errors.email}
              helperText={errors.email}
              margin="normal"
            />
            <TextField
              fullWidth
              label="Address"
              name="address"
              multiline
              rows={3}
              value={formData.address}
              onChange={handleChange}
              error={!!errors.address}
              helperText={errors.address || `${formData.address.length}/400`}
              margin="normal"
            />
            <TextField
              fullWidth
              label="Password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              type={showPassword ? "text" : "password"}
              error={!!errors.password}
              helperText={errors.password}
              margin="normal"
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => setShowPassword(!showPassword)}>
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
  <FormControl fullWidth margin="normal">
  <InputLabel>Select Role</InputLabel>

  <Select
    value={role}
    label="Select Role"
    onChange={(e) => setRole(e.target.value)}
  >
    <MenuItem value="SYSTEM_ADMIN">
      System Administrator
    </MenuItem>

    <MenuItem value="STORE_OWNER">
      Store Owner
    </MenuItem>

    <MenuItem value="NORMAL_USER">
      Normal User
    </MenuItem>
  </Select>
</FormControl>
            <Button
              fullWidth
              variant="contained"
              size="large"
              onClick={handleRegister}
              sx={{
                mt: 3,
                height: 56,
                borderRadius: 3,
                fontWeight: 700,
                textTransform: "none",
              }}
            >
              Register
            </Button>

            <Divider sx={{ my: 3 }}>OR</Divider>

            <Button
              fullWidth
              variant="outlined"
              size="large"
              onClick={() => navigate("/")}
              sx={{
                height: 56,
                borderRadius: 3,
                textTransform: "none",
                fontWeight: 600,
              }}
            >
              Already Have Account? Login
            </Button>
          </MotionPaper>
        </Grid>
      </Grid>
    </Box>
  );
}

export default Register;
