import React, { useState ,useEffect} from "react";
import {
  Chip,
} from "@mui/material";

import EditIcon from "@mui/icons-material/Edit";
import {
  Box,
  Typography,
  Grid,
  Paper,
  Avatar,
  TextField,
  InputAdornment,
  Rating,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";

import {
  Search,
  Storefront,
  Email,
  LocationOn,
  LockReset,
} from "@mui/icons-material";

import { motion } from "framer-motion";
import LogoutIcon from "@mui/icons-material/Logout";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import { useNavigate } from "react-router-dom";
import API from "../../services/api";


const MotionPaper = motion(Paper);

export default function Dashboard() {
  const [search, setSearch] = useState("");
  const [openPassword, setOpenPassword] = useState(false);
  const [openRatingModal, setOpenRatingModal] = useState(false);
  const [selectedStore, setSelectedStore] = useState(null);
  const [userRating, setUserRating] = useState(0);
  const [review, setReview] = useState("");
const [store, setStore] = useState(null);

const fetchMyStore = async () => {
  try {
    const response = await API.get(
      "/stores/my-store"
    );

    setStore(response.data);
  } catch (error) {
    console.log(error);
  }
};

useEffect(() => {
  fetchMyStore();
}, []);
  const [openReviewsModal, setOpenReviewsModal] = useState(false);
  const [selectedReviews, setSelectedReviews] = useState([]);
const navigate = useNavigate();
const loggedInUser = JSON.parse(
  localStorage.getItem("user")
);

console.log(loggedInUser);
const handleLogout = () => {
  localStorage.clear();
  navigate("/");
};
  const handleSubmitRating = () => {
    if (!selectedStore || !userRating) return;

    const updatedStores = stores.map((store) => {
      if (store.id === selectedStore.id) {
        const totalPoints = store.rating * store.reviews;

        const newReviews = store.reviews + 1;

        const newAverage = (totalPoints + userRating) / newReviews;

        return {
          ...store,
          rating: Number(newAverage.toFixed(1)),
          reviews: newReviews,
        };
      }

      return store;
    });

    setStores(updatedStores);

    alert(`Thank you! You rated ${selectedStore.name} ${userRating} stars`);

    setOpenRatingModal(false);
    setSelectedStore(null);
    setUserRating(0);
    setReview("");
  };
// const store = {
//   id: 1,
//   name: "Electronics Hub",
//   email: "electronics@gmail.com",
//   address: "Pune, Maharashtra",
//   rating: 4.8,
//   reviews: 320,

//   reviewList: [
//     {
//       id: 1,
//       user: "John Doe",
//       rating: 5,
//       comment: "Excellent products and support.",
//       date: "12 May 2026",
//     },
//     {
//       id: 2,
//       user: "Sarah Smith",
//       rating: 4,
//       comment: "Fast delivery and nice staff.",
//       date: "10 May 2026",
//     },
//     {
//       id: 3,
//       user: "Michael Johnson",
//       rating: 5,
//       comment: "Highly recommended store.",
//       date: "08 May 2026",
//     },
//     {
//       id: 4,
//       user: "Emma Watson",
//       rating: 5,
//       comment: "Best electronics store in Pune.",
//       date: "05 May 2026",
//     },
//     {
//       id: 5,
//       user: "Robert Brown",
//       rating: 4,
//       comment: "Good quality products.",
//       date: "03 May 2026",
//     },
//   ],
// };
  const [stores, setStores] = useState([
    {
      id: 1,
      name: "Electronics Hub",
      email: "electronics@gmail.com",
      address: "Pune, Maharashtra",
      rating: 4.8,
      reviews: 320,

    reviewedByCurrentUser: true,
    userRating: 5,
    userReview: "Excellent products and support.",
      reviewList: [
        {
          id: 1,
          user: "John Doe",
          rating: 5,
          comment: "Excellent products and support.",
          date: "12 May 2026",
        },
        {
          id: 2,
          user: "Sarah Smith",
          rating: 4,
          comment: "Fast delivery and nice staff.",
          date: "10 May 2026",
        },
        {
          id: 3,
          user: "Michael Johnson",
          rating: 5,
          comment: "Highly recommended store.",
          date: "08 May 2026",
        },
      ],
    },

    {
      id: 2,
      name: "Fashion World",
      email: "fashion@gmail.com",
      address: "Mumbai, Maharashtra",
      rating: 4.5,
      reviews: 245,

    reviewedByCurrentUser: true,
    userRating: 5,
    userReview: "Excellent products and support.",
      reviewList: [
        {
          id: 1,
          user: "John Doe",
          rating: 5,
          comment: "Excellent products and support.",
          date: "12 May 2026",
        },
        {
          id: 2,
          user: "Sarah Smith",
          rating: 4,
          comment: "Fast delivery and nice staff.",
          date: "10 May 2026",
        },
        {
          id: 3,
          user: "Michael Johnson",
          rating: 5,
          comment: "Highly recommended store.",
          date: "08 May 2026",
        },
      ],
    },
    {
      id: 3,
      name: "Food Corner",
      email: "food@gmail.com",
      address: "Delhi",
      rating: 4.2,
      reviews: 180,

      reviewList: [
        {
          id: 1,
          user: "John Doe",
          rating: 5,
          comment: "Excellent products and support.",
          date: "12 May 2026",
        },
        {
          id: 2,
          user: "Sarah Smith",
          rating: 4,
          comment: "Fast delivery and nice staff.",
          date: "10 May 2026",
        },
        {
          id: 3,
          user: "Michael Johnson",
          rating: 5,
          comment: "Highly recommended store.",
          date: "08 May 2026",
        },
      ],
    },
    {
      id: 4,
      name: "Mobile Planet",
      email: "mobile@gmail.com",
      address: "Bangalore",
      rating: 4.9,
      reviews: 550,

      reviewList: [
        {
          id: 1,
          user: "John Doe",
          rating: 5,
          comment: "Excellent products and support.",
          date: "12 May 2026",
        },
        {
          id: 2,
          user: "Sarah Smith",
          rating: 4,
          comment: "Fast delivery and nice staff.",
          date: "10 May 2026",
        },
        {
          id: 3,
          user: "Michael Johnson",
          rating: 5,
          comment: "Highly recommended store.",
          date: "08 May 2026",
        },
      ],
    },
  ]);

  // const filteredStores = stores.filter((store) =>
  //   store.name.toLowerCase().includes(search.toLowerCase()),
  // );
const filteredStores = stores.filter((store) =>
  store.name.toLowerCase().includes(search.toLowerCase()) ||
  store.address.toLowerCase().includes(search.toLowerCase())
);
  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#F8FAFC",
        p: 4,
      }}
    >
      {/* Welcome Banner */}

     <Paper
  elevation={0}
  sx={{
    p: 4,
    mb: 4,
    borderRadius: "28px",
    background:
      "linear-gradient(135deg,#2563EB 0%,#4F46E5 50%,#7C3AED 100%)",
    position: "relative",
    overflow: "hidden",
    color: "#fff",
  }}
>
  {/* Decorative Circles */}

  <Box
    sx={{
      position: "absolute",
      width: 250,
      height: 250,
      borderRadius: "50%",
      bgcolor: "rgba(255,255,255,0.08)",
      top: -100,
      right: -60,
    }}
  />

  <Box
    sx={{
      position: "absolute",
      width: 150,
      height: 150,
      borderRadius: "50%",
      bgcolor: "rgba(255,255,255,0.05)",
      bottom: -50,
      left: 200,
    }}
  />

  <Box
    display="flex"
    justifyContent="space-between"
    alignItems="center"
    position="relative"
    zIndex={1}
  >
    {/* Left Section */}

    <Box display="flex" alignItems="center" gap={3}>
      <Avatar
        sx={{
          width: 70,
          height: 70,
          fontSize: 28,
          fontWeight: 700,
          bgcolor: "rgba(255,255,255,0.2)",
          backdropFilter: "blur(20px)",
        }}
      >
        U
      </Avatar>

      <Box>
        <Typography
          variant="h4"
          fontWeight={800}
        >
          Welcome Back 👋
        </Typography>

        <Typography
          sx={{
            opacity: 0.9,
            mt: 1,
          }}
        >
          Browse stores, submit ratings and manage your account.
        </Typography>

        <Box
          display="flex"
          alignItems="center"
          gap={1}
          mt={1.5}
        >
        </Box>
      </Box>
    </Box>

    {/* Right Section */}

    <Button
      startIcon={<LogoutIcon />}
      onClick={handleLogout}
      sx={{
        px: 3,
        py: 1.3,
        borderRadius: "14px",
        bgcolor: "rgba(255,255,255,0.15)",
        backdropFilter: "blur(15px)",
        color: "#fff",
        border: "1px solid rgba(255,255,255,0.2)",
        fontWeight: 700,
        textTransform: "none",

        "&:hover": {
          bgcolor: "rgba(255,255,255,0.25)",
          transform: "translateY(-2px)",
        },
      }}
    >
      Logout
    </Button>
  </Box>
</Paper>

      {/* Actions */}

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <MotionPaper
            whileHover={{ y: -8 }}
            sx={{
              p: 3,
              borderRadius: 4,
              cursor: "pointer",
              background: "linear-gradient(135deg,#F59E0B,#D97706)",
              color: "#fff",
            }}
            onClick={() => setOpenPassword(true)}
          >
            <LockReset sx={{ fontSize: 40 }} />

            <Typography variant="h6" fontWeight="700" mt={2}>
              Reset Password
            </Typography>

            <Typography variant="body2">
              Change your account password
            </Typography>
          </MotionPaper>
        </Grid>
      </Grid>

      {/* Search */}


      {/* Stores */}
<Typography
  variant="h5"
  fontWeight="700"
  mt={5}
  mb={3}
>
  Featured Store
</Typography>

<Grid container>
  <Grid item xs={12} md={6}>
    <MotionPaper
      whileHover={{
        y: -10,
        scale: 1.02,
      }}
      sx={{
        p: 3,
        borderRadius: "24px",
        background: "rgba(255,255,255,0.85)",
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(255,255,255,0.3)",
        boxShadow:
          "0 20px 40px rgba(0,0,0,0.08)",
      }}
    >
      <Box display="flex" gap={2}>
        <Avatar
          sx={{
            width: 70,
            height: 70,
            background:
              "linear-gradient(135deg,#2563EB,#60A5FA)",
          }}
        >
          <Storefront />
        </Avatar>

        <Box>
          <Typography
            variant="h5"
            fontWeight="700"
          >
            {store?.name}
          </Typography>

        </Box>
      </Box>

      <Box mt={3}>
        <Typography>
          📧 {store?.email}
        </Typography>

        <Typography mt={1}>
          📍 {store?.address}
        </Typography>

    <Box
  mt={3}
  sx={{
    p: 2,
    borderRadius: 3,
    bgcolor: "#F8FAFC",
    border: "1px solid #E2E8F0",
  }}
>
  <Typography
    variant="subtitle2"
    color="text.secondary"
    gutterBottom
  >
    Average Store Rating
  </Typography>

  <Box
    display="flex"
    justifyContent="space-between"
    alignItems="center"
  >
    <Box>
      <Typography
        variant="h4"
        fontWeight="700"
        color="primary"
      >
        {store?.rating}
      </Typography>

      <Rating
        value={store?.rating}
        precision={0.1}
        readOnly
      />
    </Box>

    <Box textAlign="right">
      <Typography
        variant="h6"
        fontWeight="700"
      >
        {store?.reviews}
      </Typography>

      <Typography
        variant="body2"
        color="text.secondary"
      >
        Total Reviews
      </Typography>
    </Box>
  </Box>
</Box>

        <Button
          variant="contained"
          sx={{
            mt: 3,
            borderRadius: 3,
            textTransform: "none",
          }}
          onClick={() =>
            setOpenReviewsModal(true)
          }
        >
          View All Reviews ({store?.reviews})
        </Button>
      </Box>
    </MotionPaper>
  </Grid>
</Grid>
      {/* Reset Password Modal */}

      <Dialog
        open={openPassword}
        onClose={() => setOpenPassword(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Reset Password</DialogTitle>

        <DialogContent>
          <TextField
            fullWidth
            label="Current Password"
            type="password"
            margin="normal"
          />

          <TextField
            fullWidth
            label="New Password"
            type="password"
            margin="normal"
          />

          <TextField
            fullWidth
            label="Confirm Password"
            type="password"
            margin="normal"
          />
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setOpenPassword(false)}>Cancel</Button>

          <Button variant="contained">Update Password</Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={openRatingModal}
        onClose={() => setOpenRatingModal(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Rate Store</DialogTitle>

        <DialogContent>
          <Typography variant="h6" gutterBottom>
            {selectedStore?.name}
          </Typography>

          <Rating
            value={userRating}
            onChange={(e, newValue) => setUserRating(newValue)}
            size="large"
            sx={{ mb: 3 }}
          />

          <TextField
            fullWidth
            multiline
            rows={4}
            label="Write Review"
            value={review}
            onChange={(e) => setReview(e.target.value)}
          />
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setOpenRatingModal(false)}>Cancel</Button>

          <Button
            variant="contained"
            onClick={handleSubmitRating}
            disabled={!userRating}
          >
            Submit Rating
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
  open={openReviewsModal}
  onClose={() => setOpenReviewsModal(false)}
  maxWidth="md"
  fullWidth
>
  <DialogTitle
    sx={{
      fontWeight: 700,
      fontSize: "24px",
    }}
  >
    ⭐ Customer Reviews
  </DialogTitle>

  <DialogContent>
    <Grid container spacing={2}>
      {selectedReviews.map((review) => (
        <Grid item xs={12} key={review.id}>
          <Paper
            sx={{
              p: 3,
              borderRadius: 4,
              background:
                "rgba(255,255,255,0.8)",
              backdropFilter: "blur(20px)",
              border:
                "1px solid rgba(255,255,255,0.4)",
            }}
          >
            <Box
              display="flex"
              justifyContent="space-between"
            >
              <Typography
                fontWeight={700}
              >
                {review.user}
              </Typography>

              <Typography
                color="text.secondary"
              >
                {review.date}
              </Typography>
            </Box>

            <Rating
              value={review.rating}
              readOnly
              sx={{ mt: 1 }}
            />

            <Typography
              sx={{
                mt: 2,
                color: "#64748B",
              }}
            >
              {review.comment}
            </Typography>
          </Paper>
        </Grid>
      ))}
    </Grid>
  </DialogContent>

  <DialogActions>
    <Button
      onClick={() =>
        setOpenReviewsModal(false)
      }
    >
      Close
    </Button>
  </DialogActions>
</Dialog>
<Dialog
  open={openReviewsModal}
  onClose={() =>
    setOpenReviewsModal(false)
  }
  maxWidth="md"
  fullWidth
>
  <DialogTitle
    sx={{
      fontWeight: 700,
      fontSize: 24,
    }}
  >
    ⭐ Electronics Hub Reviews
  </DialogTitle>

<DialogContent>
  <Grid container spacing={2}>
    {store?.reviewList?.map((review) => (
      <Grid item xs={12} key={review.id}>
        <Paper
          sx={{
            p: 3,
            borderRadius: 4,
            background: "rgba(248,250,252,0.8)",
          }}
        >
          <Box
            display="flex"
            justifyContent="space-between"
          >
            <Typography fontWeight={700}>
              {review.user}
            </Typography>

            <Typography color="text.secondary">
              {review.date}
            </Typography>
          </Box>

          <Rating
            value={review.rating}
            readOnly
            sx={{ mt: 1 }}
          />

          <Typography mt={2}>
            {review.comment}
          </Typography>
        </Paper>
      </Grid>
    ))}
  </Grid>
</DialogContent>

  <DialogActions>
    <Button
      onClick={() =>
        setOpenReviewsModal(false)
      }
    >
      Close
    </Button>
  </DialogActions>
</Dialog>
    </Box>
  );
}
