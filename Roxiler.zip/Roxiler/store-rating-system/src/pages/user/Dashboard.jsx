import React, { useState,useEffect } from "react";
import { Chip } from "@mui/material";

import EditIcon from "@mui/icons-material/Edit";
import {
  Box,
  Typography,
  Grid,
  Paper,
  Avatar,
  TextField,
  InputAdornment,
  Rating,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";

import {
  Search,
  Storefront,
  Email,
  LocationOn,
  LockReset,
} from "@mui/icons-material";

import { motion } from "framer-motion";
import LogoutIcon from "@mui/icons-material/Logout";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import { useNavigate } from "react-router-dom";
import API from "../../services/api";

const MotionPaper = motion(Paper);

export default function Dashboard() {
  const [search, setSearch] = useState("");
  const [openPassword, setOpenPassword] = useState(false);
  const [openRatingModal, setOpenRatingModal] = useState(false);
  const [selectedStore, setSelectedStore] = useState(null);
  const [userRating, setUserRating] = useState(0);
  const [review, setReview] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
const [profile, setProfile] =
  useState(null);
  const [newPassword, setNewPassword] = useState("");

  const [confirmPassword, setConfirmPassword] = useState("");

  // const [openReviewsModal, setOpenReviewsModal] = useState(false);
  // const [selectedReviews, setSelectedReviews] = useState([]);
  const navigate = useNavigate();
const [stores, setStores] = useState([]);
const [user, setUser] = useState(null);

const [selectedReviews, setSelectedReviews] = useState([]);
const [openReviewsModal, setOpenReviewsModal] =
  useState(false);
  const handleResetPassword = async () => {
  try {
    if (newPassword !== confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    const user = JSON.parse(localStorage.getItem("user"));

    const response = await API.put(
      "/auth/reset-password",
      {
        email: user.email,
        currentPassword,
        newPassword,
      }
    );

    alert(response.data.message);

    setOpenPassword(false);

    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  } catch (error) {
    alert(
      error.response?.data?.message ||
        "Password update failed"
    );
  }
};



useEffect(() => {
  const fetchProfile = async () => {
    try {
      const user = JSON.parse(
        localStorage.getItem("user")
      );

      const response =
        await API.get(
          `/users/profile/${user.id}`
        );

      setProfile(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  fetchProfile();
}, []);
 
  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };
  const fetchReviews = async (
  storeId
) => {
  try {
    const response =
      await API.get(
        `/ratings/store/${storeId}`
      );

    setSelectedReviews(
      response.data
    );

    setOpenReviewsModal(true);
  } catch (error) {
    console.log(error);
  }
};
 const handleSubmitRating = async () => {
  try {
    if (selectedStore.reviewedByCurrentUser) {
      await API.put(
        `/ratings/${selectedStore.ratingId}`,
        {
          rating: userRating,
          review,
        }
      );
    } else {
      await API.post("/ratings", {
        storeId: selectedStore.id,
        rating: userRating,
        review,
      });
    }

    fetchStores();

    setOpenRatingModal(false);

    setUserRating(0);
    setReview("");
  } catch (error) {
    console.log(error);
  }
};

 const fetchStores = async () => {
  try {
    const response =
      await API.get("/stores");

    setStores(response.data);
  } catch (error) {
    console.log(error);
  }
};
useEffect(() => {
  fetchStores();
}, []);

  // const filteredStores = stores.filter((store) =>
  //   store.name.toLowerCase().includes(search.toLowerCase()),
  // );
  const filteredStores = stores.filter(
    (store) =>
      store.name.toLowerCase().includes(search.toLowerCase()) ||
      store.address.toLowerCase().includes(search.toLowerCase()),
  );
  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#F8FAFC",
        p: 4,
      }}
    >
      {/* Welcome Banner */}

      <Paper
        elevation={0}
        sx={{
          p: 4,
          mb: 4,
          borderRadius: "28px",
          background:
            "linear-gradient(135deg,#2563EB 0%,#4F46E5 50%,#7C3AED 100%)",
          position: "relative",
          overflow: "hidden",
          color: "#fff",
        }}
      >
        {/* Decorative Circles */}

        <Box
          sx={{
            position: "absolute",
            width: 250,
            height: 250,
            borderRadius: "50%",
            bgcolor: "rgba(255,255,255,0.08)",
            top: -100,
            right: -60,
          }}
        />

        <Box
          sx={{
            position: "absolute",
            width: 150,
            height: 150,
            borderRadius: "50%",
            bgcolor: "rgba(255,255,255,0.05)",
            bottom: -50,
            left: 200,
          }}
        />

        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          position="relative"
          zIndex={1}
        >
          {/* Left Section */}

          <Box display="flex" alignItems="center" gap={3}>
            <Avatar
  sx={{
    width: 70,
    height: 70,
    fontSize: 28,
    fontWeight: 700,
    bgcolor: "rgba(255,255,255,0.2)",
  }}
>
  {profile?.name
    ?.charAt(0)
    ?.toUpperCase()}
</Avatar>
<Typography
  variant="h5"
  fontWeight="700"
  mt={2}
>
  {profile?.name}
</Typography>

            <Box>
              <Typography variant="h4" fontWeight={800}>
                Welcome Back 👋
              </Typography>

              <Typography
                sx={{
                  opacity: 0.9,
                  mt: 1,
                }}
              >
                Browse stores, submit ratings and manage your account.
              </Typography>

              <Box display="flex" alignItems="center" gap={1} mt={1.5}></Box>
            </Box>
          </Box>

          {/* Right Section */}

          <Button
            startIcon={<LogoutIcon />}
            onClick={handleLogout}
            sx={{
              px: 3,
              py: 1.3,
              borderRadius: "14px",
              bgcolor: "rgba(255,255,255,0.15)",
              backdropFilter: "blur(15px)",
              color: "#fff",
              border: "1px solid rgba(255,255,255,0.2)",
              fontWeight: 700,
              textTransform: "none",

              "&:hover": {
                bgcolor: "rgba(255,255,255,0.25)",
                transform: "translateY(-2px)",
              },
            }}
          >
            Logout
          </Button>
        </Box>
      </Paper>

      {/* Actions */}

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <MotionPaper
            whileHover={{ y: -8 }}
            sx={{
              p: 3,
              borderRadius: 4,
              cursor: "pointer",
              background: "linear-gradient(135deg,#F59E0B,#D97706)",
              color: "#fff",
            }}
            onClick={() => setOpenPassword(true)}
          >
            <LockReset sx={{ fontSize: 40 }} />

            <Typography variant="h6" fontWeight="700" mt={2}>
              Reset Password
            </Typography>

            <Typography variant="body2">
              Change your account password
            </Typography>
          </MotionPaper>
        </Grid>
      </Grid>

      {/* Search */}

      <Paper
        sx={{
          mt: 4,
          p: 3,
          borderRadius: 4,
        }}
      >
        <TextField
          fullWidth
          placeholder="Search by Store Name or Location..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Search />
              </InputAdornment>
            ),
          }}
        />
      </Paper>

      {/* Stores */}

      <Typography variant="h5" fontWeight="700" mt={5} mb={3}>
        Registered Stores
      </Typography>
      <br />
      {/* <Grid container spacing={3}>
        {filteredStores.map((store) => (
          <Grid item xs={12} md={6} lg={4} key={store.id}>
            <MotionPaper
              whileHover={{
                y: -10,
                scale: 1.02,
              }}
              transition={{ duration: 0.3 }}
              sx={{
                p: 3,
                borderRadius: "24px",

                background: "rgba(255,255,255,0.85)",

                backdropFilter: "blur(20px)",

                border: "1px solid rgba(255,255,255,0.3)",

                boxShadow: "0 20px 40px rgba(0,0,0,0.08)",
                width:'300px'
              }}
            >
              <Box display="flex" alignItems="center" gap={2}>
                <Avatar
                  sx={{
                    width: 65,
                    height: 65,
                    background: "linear-gradient(135deg,#2563EB,#60A5FA)",
                  }}
                >
                  <Storefront />
                </Avatar>

                <Box>
                  <Typography variant="h6" fontWeight="700">
                    {store.name}
                  </Typography>

                  <Typography color="text.secondary">Active Store</Typography>
                </Box>
              </Box>

              <Box mt={3}>
                <Box display="flex" alignItems="center" gap={1} mb={2}>
                  <Email color="primary" />

                  <Typography>{store.email}</Typography>
                </Box>

                <Box display="flex" alignItems="center" gap={1} mb={2}>
                  <LocationOn color="error" />

                  <Typography>{store.address}</Typography>
                </Box>

                <Rating value={store.rating} precision={0.1} readOnly />

                <Typography color="text.secondary" mt={1}>
                  {store.rating} / 5
                </Typography>

                <Button
                  variant="text"
                  onClick={() => {
                    setSelectedReviews(store.reviewList);
                    setOpenReviewsModal(true);
                  }}
                  sx={{
                    p: 0,
                    mt: 1,
                    textTransform: "none",
                    fontWeight: 700,
                  }}
                >
                  {store.reviews} Reviews
                </Button>

                <Button
                  fullWidth
                  variant="contained"
                  onClick={() => {
                    setSelectedStore(store);
                    setOpenRatingModal(true);
                  }}
                  sx={{
                    mt: 3,
                    height: 50,
                    borderRadius: 3,
                    textTransform: "none",
                    fontWeight: 700,
                  }}
                >
                  Rate Store
                </Button>
              </Box>
            </MotionPaper>
          </Grid>
        ))}
      </Grid> */}
      <Grid container spacing={3}>
        {filteredStores.map((store) => (
          <Grid item xs={12} md={6} lg={4} key={store.id}>
            <MotionPaper
              whileHover={{
                y: -10,
                scale: 1.02,
              }}
              transition={{ duration: 0.3 }}
              sx={{
                p: 3,
                borderRadius: "24px",
                background: "rgba(255,255,255,0.85)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(255,255,255,0.3)",
                boxShadow: "0 20px 40px rgba(0,0,0,0.08)",
                width: "300px",
                position: "relative",
              }}
            >
              {/* Header */}

              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="flex-start"
              >
                <Box display="flex" alignItems="center" gap={2}>
                  <Avatar
                    sx={{
                      width: 65,
                      height: 65,
                      background: "linear-gradient(135deg,#2563EB,#60A5FA)",
                    }}
                  >
                    <Storefront />
                  </Avatar>

                  <Box>
                    <Typography variant="h6" fontWeight="700">
                      {store.name}
                    </Typography>

                    <Typography color="text.secondary">Active Store</Typography>
                  </Box>
                </Box>

               {store.isReviewed && (
  <Chip
    label="Reviewed"
    color="success"
    sx={{
      position: "absolute",
      top: 15,
      right: 15,
      fontWeight: 700,
    }}
  />
)}
              </Box>

              {/* Store Details */}

              <Box mt={3}>
                <Box display="flex" alignItems="center" gap={1} mb={2}>
                  <Email color="primary" />
                  <Typography variant="body2">{store.email}</Typography>
                </Box>

                <Box display="flex" alignItems="center" gap={1} mb={2}>
                  <LocationOn color="error" />
                  <Typography variant="body2">{store.address}</Typography>
                </Box>

                <Rating value={store.rating} precision={0.1} readOnly />

                <Typography color="text.secondary" mt={1}>
                  {store.rating} / 5
                </Typography>

               <Button
  onClick={() =>
    fetchReviews(store.id)
  }
>
  {store.reviews} Reviews
</Button>

                {/* Bottom Actions */}

                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  mt={3}
                >
                  {store.reviewedByCurrentUser ? (
                    <>
                      <Button
                        variant="outlined"
                        onClick={() => {
                          setSelectedStore(store);
                          setUserRating(store.userRating || 0);
                          setReview(store.userReview || "");
                          setOpenRatingModal(true);
                        }}
                        sx={{
                          borderRadius: 3,
                          textTransform: "none",
                          fontWeight: 700,
                        }}
                      >
                        Edit Review
                      </Button>

                      <Chip color="success" label={`⭐ ${store.userRating}`} />
                    </>
                  ) : (
                    <Button
                      fullWidth
                      variant="contained"
                      onClick={() => {
                        setSelectedStore(store);
                        setOpenRatingModal(true);
                      }}
                      sx={{
                        height: 50,
                        borderRadius: 3,
                        textTransform: "none",
                        fontWeight: 700,
                      }}
                    >
                      Rate Store
                    </Button>
                  )}
                </Box>
              </Box>
            </MotionPaper>
          </Grid>
        ))}
      </Grid>
      {/* Reset Password Modal */}

      <Dialog
        open={openPassword}
        onClose={() => setOpenPassword(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Reset Password</DialogTitle>

        <DialogContent>
          <TextField
            fullWidth
            label="Current Password"
            type="password"
            margin="normal"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
          />

          <TextField
            fullWidth
            label="New Password"
            type="password"
            margin="normal"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />

          <TextField
            fullWidth
            label="Confirm Password"
            type="password"
            margin="normal"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setOpenPassword(false)}>Cancel</Button>

          <Button variant="contained" onClick={handleResetPassword}>
            Update Password
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={openRatingModal}
        onClose={() => setOpenRatingModal(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Rate Store</DialogTitle>

        <DialogContent>
          <Typography variant="h6" gutterBottom>
            {selectedStore?.name}
          </Typography>

          <Rating
            value={userRating}
            onChange={(e, newValue) => setUserRating(newValue)}
            size="large"
            sx={{ mb: 3 }}
          />

          <TextField
            fullWidth
            multiline
            rows={4}
            label="Write Review"
            value={review}
            onChange={(e) => setReview(e.target.value)}
          />
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setOpenRatingModal(false)}>Cancel</Button>

          <Button
            variant="contained"
            onClick={handleSubmitRating}
            disabled={!userRating}
          >
            Submit Rating
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={openReviewsModal}
        onClose={() => setOpenReviewsModal(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle
          sx={{
            fontWeight: 700,
            fontSize: "24px",
          }}
        >
          ⭐ Customer Reviews
        </DialogTitle>

        <DialogContent>
          <Grid container spacing={2}>
            {selectedReviews.map((review) => (
              <Grid item xs={12} key={review.id}>
                <Paper
                  sx={{
                    p: 3,
                    borderRadius: 4,
                    background: "rgba(255,255,255,0.8)",
                    backdropFilter: "blur(20px)",
                    border: "1px solid rgba(255,255,255,0.4)",
                  }}
                >
                  <Box display="flex" justifyContent="space-between">
                    <Typography fontWeight={700}>{review.user}</Typography>

                    <Typography color="text.secondary">
                      {review.date}
                    </Typography>
                  </Box>

                  <Rating value={review.rating} readOnly sx={{ mt: 1 }} />

                  <Typography
                    sx={{
                      mt: 2,
                      color: "#64748B",
                    }}
                  >
                    {review.comment}
                  </Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setOpenReviewsModal(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
