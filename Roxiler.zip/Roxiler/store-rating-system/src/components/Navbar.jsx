import React from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Typography,
  Avatar,
  IconButton,
  Badge,
  TextField,
} from "@mui/material";

import {
  Notifications,
  Search,
} from "@mui/icons-material";

export default function Navbar() {
  const navigate = useNavigate();
  const handleLogout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("user");

  navigate("/");
};
  return (
    <Box
      sx={{
        height: 80,
        bgcolor: "#FFFFFF",
        borderRadius: 4,
        px: 4,
        display: "flex",
        alignItems: "center",
        justifyContent:
          "space-between",
        boxShadow:
          "0 10px 30px rgba(0,0,0,0.04)",
      }}
    >
      <Typography
        variant="h5"
        fontWeight="700"
      >
        Dashboard
      </Typography>

      
    </Box>
  );
}