import { Card, CardContent, Typography } from "@mui/material";
import { motion } from "framer-motion";

function StatsCard({
  title,
  value,
  icon
}) {
  return (
    <motion.div
      whileHover={{
        y: -8,
        scale: 1.03,
      }}
    >
      <Card
        sx={{
          borderRadius: 4,
          background:
            "linear-gradient(135deg,#6366F1,#8B5CF6)",
          color: "white",
        }}
      >
        <CardContent>
          {icon}

          <Typography variant="body2">
            {title}
          </Typography>

          <Typography variant="h4">
            {value}
          </Typography>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default StatsCard;