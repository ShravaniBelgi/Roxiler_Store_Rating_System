import React from "react";
import {
  Box,
  Typography,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
} from "@mui/material";

import {
  Dashboard,
  People,
  Store,
  Star,
  Analytics,
  Settings,
  Logout,
} from "@mui/icons-material";

import { useNavigate, useLocation } from "react-router-dom";

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    {
      text: "Dashboard",
      icon: <Dashboard />,
      path: "/admin/dashboard",
    },
    {
      text: "Stores",
      icon: <Store />,
      path: "/admin/stores",
    },
    {
      text: "Users",
      icon: <People />,
      path: "/admin/users",
    },
    
    // {
    //   text: "Ratings",
    //   icon: <Star />,
    //   path: "/admin/ratings",
    // },
    // {
    //   text: "Analytics",
    //   icon: <Analytics />,
    //   path: "/admin/analytics",
    // },
  ];

  return (
    <Box
      sx={{
        width: 280,
        height: "100vh",
        position: "fixed",
        left: 0,
        top: 0,
        background:
          "linear-gradient(180deg,#0F172A,#111827)",
        color: "#fff",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* LOGO */}

      <Box
        sx={{
          p: 4,
          textAlign: "center",
        }}
      >
        <Typography
          variant="h5"
          fontWeight="700"
        >
          ⭐ Store Rating
        </Typography>

        <Typography
          variant="body2"
          sx={{
            color: "#94A3B8",
            mt: 1,
          }}
        >
          Admin Panel
        </Typography>
      </Box>

      <Divider
        sx={{
          borderColor:
            "rgba(255,255,255,0.1)",
        }}
      />

      {/* MENU */}

      <List sx={{ px: 2, mt: 2 }}>
        {menuItems.map((item) => (
          <ListItemButton
            key={item.text}
            onClick={() =>
              navigate(item.path)
            }
            sx={{
              borderRadius: 3,
              mb: 1,

              backgroundColor:
                location.pathname ===
                item.path
                  ? "#2563EB"
                  : "transparent",

              "&:hover": {
                backgroundColor:
                  "#1E40AF",
                transform:
                  "translateX(6px)",
              },

              transition: "0.3s",
            }}
          >
            <ListItemIcon
              sx={{
                color: "#fff",
                minWidth: 40,
              }}
            >
              {item.icon}
            </ListItemIcon>

            <ListItemText
              primary={item.text}
            />
          </ListItemButton>
        ))}
      </List>

      <Box sx={{ flexGrow: 1 }} />

      {/* SETTINGS */}

      <Box sx={{ p: 2 }}>
        {/* <ListItemButton
          sx={{
            borderRadius: 3,
            mb: 1,

            "&:hover": {
              backgroundColor:
                "#334155",
            },
          }}
        >
          <ListItemIcon
            sx={{
              color: "#fff",
            }}
          >
            <Settings />
          </ListItemIcon>

          <ListItemText primary="Settings" />
        </ListItemButton> */}

        <ListItemButton
          onClick={() => navigate("/")}
          sx={{
            borderRadius: 3,

            "&:hover": {
              backgroundColor:
                "#DC2626",
            },
          }}
        >
          <ListItemIcon
            sx={{
              color: "#fff",
            }}
          >
            <Logout />
          </ListItemIcon>

          <ListItemText primary="Logout" />
        </ListItemButton>
      </Box>
    </Box>
  );
}